package com.project.recyclerviewinterntutorial;

import android.content.SharedPreferences;
import android.graphics.ColorSpace;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements Adapter.OnItemClickListener {
    EditText name,age;
    TextView tvname,tvage;
    RecyclerView rvUser;

    ExtendedFloatingActionButton fabNewUser;
    Adapter adapter;
    ArrayList<ModelClass> usersList;
    Button Add,Show;
    Random rand = new Random();
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rvUser = findViewById(R.id.rv_users);
        name = findViewById(R.id.name);
        age = findViewById(R.id.age);
        fabNewUser = findViewById(R.id.fab_new_user);
        usersList = new ArrayList<>();
        Add = findViewById(R.id.Add);
        Show = findViewById(R.id.Show);
        tvname = findViewById(R.id.tvname);
        tvage = findViewById(R.id.tvage);

        showshared();
        setUpRv();
         addData();

        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               if(!name.getText().toString().isEmpty()&!age.getText().toString().isEmpty()){
                   shared(name.getText().toString(), Integer.parseInt(age.getText().toString()));
                   showshared();
                   name.setText("");
                   age.setText("");
               }
               else{
                   Toast.makeText(getApplicationContext(),"Enter data",Toast.LENGTH_LONG).show();
               }
//                sharedPreferences = getSharedPreferences("myshared", MODE_PRIVATE);
//// The value will be default as empty string because for
//// the very first time when the app is opened, there is nothing to show
//                String s1 = sharedPreferences.getString("name", "");
//                int a = sharedPreferences.getInt("age", 0);

// We can then use the data


            }
        });

        Show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addData();

            }
        });


        fabNewUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addData();
            }
        });
        }

    public void addData() {
        int number = rand.nextInt(10 - 1 + 1)+ 1;
         sharedPreferences = getSharedPreferences("myshared", MODE_PRIVATE);
        String s1 = sharedPreferences.getString("name", "");
        int a = sharedPreferences.getInt("age", 0);
        if(!s1.equals("")){
            usersList.add(new ModelClass(s1,a,number));
        }

        adapter.setData(usersList);
        }

    public void setUpRv() {
        rvUser.setHasFixedSize(true);
        rvUser.setLayoutManager(new LinearLayoutManager(this));
        adapter = new Adapter(MainActivity.this);
        rvUser.setAdapter(adapter);
        }

    @Override
    public void onItemClick(int number) {
        Toast.makeText(MainActivity.this, "" + number, Toast.LENGTH_SHORT).show();
           }




           public  void shared(String name,int age){


            sharedPreferences = getSharedPreferences("myshared",MODE_PRIVATE);
               SharedPreferences.Editor myEdit = sharedPreferences.edit();
               myEdit.putString("name", name);
               myEdit.putInt("age",age);
                myEdit.commit();


           }



public void showshared(){
    sharedPreferences = getSharedPreferences("myshared", MODE_PRIVATE);
// The value will be default as empty string because for
// the very first time when the app is opened, there is nothing to show
    String s1 = sharedPreferences.getString("name", "");
    int a = sharedPreferences.getInt("age", 0);
    if(!s1.equals("")){
        tvname.setText(s1);
        tvage.setText(String.valueOf(a));
    }
    else{
        tvname.setText("empty");
        tvage.setText(String.valueOf(0));
    }

}



           }





