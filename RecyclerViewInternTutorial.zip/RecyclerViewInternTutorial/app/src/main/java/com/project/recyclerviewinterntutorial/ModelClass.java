package com.project.recyclerviewinterntutorial;

public class ModelClass {

    String name;
    int age;
    int number;

    public ModelClass(String name, int age, int number) {
        this.name = name;
        this.age = age;
        this.number = number;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getNumber() {
        return number;
    }
}
